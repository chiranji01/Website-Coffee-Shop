-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Oct 14, 2022 at 05:45 PM
-- Server version: 5.7.36
-- PHP Version: 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cofeeshop`
--

-- --------------------------------------------------------

--
-- Table structure for table `bill`
--

DROP TABLE IF EXISTS `bill`;
CREATE TABLE IF NOT EXISTS `bill` (
  `BIllNum` int(11) NOT NULL AUTO_INCREMENT,
  `Date` date NOT NULL,
  `TIme` time NOT NULL,
  `Total` int(11) NOT NULL,
  `Description` varchar(100) NOT NULL,
  PRIMARY KEY (`BIllNum`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cofee`
--

DROP TABLE IF EXISTS `cofee`;
CREATE TABLE IF NOT EXISTS `cofee` (
  `CofeeID` int(11) NOT NULL,
  `CategoryID` int(11) NOT NULL,
  `CategoryName` varchar(20) NOT NULL,
  PRIMARY KEY (`CofeeID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cofeeshop`
--

DROP TABLE IF EXISTS `cofeeshop`;
CREATE TABLE IF NOT EXISTS `cofeeshop` (
  `shopID` int(11) NOT NULL,
  `ShopName` varchar(20) NOT NULL,
  `Phone` varchar(15) NOT NULL,
  PRIMARY KEY (`shopID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
CREATE TABLE IF NOT EXISTS `customer` (
  `CID` int(11) NOT NULL AUTO_INCREMENT,
  `CName` varchar(50) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Age` int(11) NOT NULL,
  PRIMARY KEY (`CID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

DROP TABLE IF EXISTS `employee`;
CREATE TABLE IF NOT EXISTS `employee` (
  `Email` varchar(50) NOT NULL,
  `SSN` varchar(20) NOT NULL,
  `Contact` varchar(15) NOT NULL,
  `EmpName` varchar(50) NOT NULL,
  PRIMARY KEY (`SSN`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `order`
--

DROP TABLE IF EXISTS `order`;
CREATE TABLE IF NOT EXISTS `order` (
  `OrderName` varchar(50) NOT NULL,
  `Quantity` varchar(10) NOT NULL,
  `Description` varchar(100) NOT NULL,
  `TimeCompleted` varchar(10) NOT NULL,
  `Date` varchar(20) NOT NULL,
  PRIMARY KEY (`OrderName`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
